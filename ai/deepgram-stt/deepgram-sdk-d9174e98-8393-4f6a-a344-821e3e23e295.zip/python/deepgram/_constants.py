DEFAULT_ENDPOINT = "https://api.deepgram.com/v1"
